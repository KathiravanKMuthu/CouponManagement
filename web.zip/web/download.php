<div class="container">
<div class="download-panel">
    <h3 class="sign-title">DOWNLOAD DEALDIO APP TODAY</h3>
    <div class="row row-rl-0">
        <div class="col-sm-6 col-md-6 col-left">
            <div class="form-group">
                <img src="images/app2.png" style="width:100%;"	>
            </div>
        </div>
        <div class="col-sm-6 col-md-6 col-right">
            <div class="social-login">
                <div class="top">
                    <h3>Introducing your new way to save money</h3>
                    <br>
					<p>In many countries, the term ‘Dio’ means to give. At DealDio, we’ve taken this one step further by providing you as the consumer an app that collects all of the offers on the high street and puts them all in one place! With over 100 businesses on board, we strive to become the home of UK offers and deals.</p>
				</div>
                <br><br><br>
                <div class="down">
                    <a href="https://play.google.com/store/apps/details?id=com.zecast.dealdio" target="_blank"><img src="images/adriod_logo.png" width="150"></a>
                    <a href="https://itunes.apple.com/gb/app/dealdio/id1380777980?mt=8" target="_blank"><img src="images/ios_logo.png" width="150"></a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>