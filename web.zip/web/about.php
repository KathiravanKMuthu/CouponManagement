<div class="container">
	<div class="ptb-30 prl-30" style="padding:30px;background-color:#fff;margin-top:5%;margin-bottom:5%;border-radius:5px;"> 
		<h3 class="" style="text-transform:uppercase;margin-bottom:40px;background:linear-gradient(to right,red 10%,grey 90%)no-repeat;background-size:100% 2px;background-position:left bottom;">About Us</h3>        
		<p class="mb-20" style="margin-bottom:20px;">DealDio is the latest way to save money when you shop on the high street! Save money on hundreds of your favourite brands and more, no matter where you are. You can find deals and special offers at a number of your local supermarkets, businesses and online services in the city, all from the palm of your hand!</p>
		<p class="mb-20" style="margin-bottom:20px;">By bringing the high street into the 21st century, we aim to give back to the local businesses and support them with a platform and an online profile to stand out on, giving them a new customer base that they may have missed out on by not showcasing themselves online.</p>
		<p class="mb-20" style="margin-bottom:20px;">Our deals are all set by the businesses themselves meaning you can walk in with confidence, and leave feeling like a winner knowing you�ve just bagged yourself a bargain!</p>
		<p class="mb-20" style="margin-bottom:20px;">DealDio - Keep Calm, Save Money.</p>
    </div>
</div>