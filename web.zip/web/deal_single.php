<?php 
$sms=  filter_input(INPUT_GET,'msg');	
$psid=  filter_input(INPUT_GET,'pro_id');	
?>

<script src="js/jquery-3.3.1.min.js"></script>
<script language="javascript" type="text/javascript">
	
	$(document).ready(function(){
		
	var repmsg="<?php if($sms!=""){ echo $sms;}?>";
	var usrid="<?php if(isset($_SESSION['user_id'])) {echo $_SESSION['user_id'];}?>";
	
	if(repmsg!=""){alert(repmsg);}

		
		
		var sx='{"return_code":1,"return_message":"New Record Inserted Successfully."}';
		var ax='{"return_code":1,"return_message":"Already Accepted this deal!"}';
		var sts="";
		
  		$('#acpbtnid').click(function(){		
		var did="";
		
		$('input:checked').each(function(){
			did=$(this).attr("id");
		});
				
			
			var qcode=$('#qrcode').val();
			var usid=$('#usrid').val();
							    
			var dataString = 'deal_id='+did+'&qrcode_string='+qcode+'&user_id='+usid;	
			$.ajax({
			type: "POST",
			url: "api/deals.php",//ajaxprocess.php
			data: dataString,
			/*success: function(data) {
				if(data==ax){
					alert("Already Accept this Deal.");
					
				}
				else{
					window.location.href="index.php";
				}
			}*/
			
			
  }).done(function(){
	  sts="D";
  })
  .fail(function(){
	  sts="F";
  })
  .always(function(){
	  if(sts=="D"){alert("Already Accepted this Deal..!");}
	  if(sts=="F"){alert("Deal Accepted Successfully...");}
	  
  });
			
			
		});
	});
	
</script>
    					
    <script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        jssor_1_slider_init = function() {

            var jssor_1_options = {
              $AutoPlay: 1,
              $AutoPlaySteps: 5,
              $SlideDuration: 160,
              $SlideWidth: 200,
              $SlideSpacing: 3,
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$,
                $Steps: 5
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 980;

            function ScaleSlider() {
                var containerElement = jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    jssor_1_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
    </script>
    <style>
        /*jssor slider loading skin spin css*/
        .jssorl-009-spin img {
            animation-name: jssorl-009-spin;
            animation-duration: 1.6s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        }

        @keyframes jssorl-009-spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        /*jssor slider bullet skin 057 css*/
        .jssorb057 .i {position:absolute;cursor:pointer;}
        .jssorb057 .i .b {fill:none;stroke:#fff;stroke-width:2000;stroke-miterlimit:10;stroke-opacity:0.4;}
        .jssorb057 .i:hover .b {stroke-opacity:.7;}
        .jssorb057 .iav .b {stroke-opacity: 1;}
        .jssorb057 .i.idn {opacity:.3;}

        /*jssor slider arrow skin 073 css*/
        .jssora073 {display:block;position:absolute;cursor:pointer;}
        .jssora073 .a {fill:#ddd;fill-opacity:.7;stroke:#000;stroke-width:160;stroke-miterlimit:10;stroke-opacity:.7;}
        .jssora073:hover {opacity:.8;}
        .jssora073.jssora073dn {opacity:.4;}
        .jssora073.jssora073ds {opacity:.3;pointer-events:none;}
    </style>

<div class="container">
			<?php 
				$table_name='deal_info';
				$where_condition ='deal_id='.$psid;
				//$order_by='merchant_id';
				$response_array = $db->get($table_name,$where_condition); 
				$dts=$response_array['return_message'];
				foreach($dts as $ar){					
								
				//echo $ar['deal_id']."\n".$ar['title'];
				?>
	<div class="row">
		<div class="col-lg-8 col-xs-12"  style="">
			<div class="row" style="background-color:#fff;border-radius:4px;margin-top:10px;margin-left:10px;">
				<div class="row" style="margin:0px;background-color:#fff;">
					<img alt="" src="<?php echo $ar['image_dir'];?>" draggable="false" style="width:100%;border-radius:4px;">
				</div>
				<div class="row" style="margin:0px;background-color:#fff;">
    <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:150px;overflow:hidden;visibility:hidden;">
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/spin.svg" />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:150px;overflow:hidden;">
						<?php   $table_name='deal_info';
								$where_condition ='deal_id='.$psid;
								$response_array = $db->get($table_name,$where_condition);
								$dts=$response_array['return_message'];								
								$dts2=array_slice($dts,0,6);
								foreach($dts2 as $ar){		
								$st= explode('/',strrev($ar['image_dir']));
								$dir="";		
								$tdir=count($st);								
								$tdir=$tdir-1;								
								for($i=1;$i<count($st);$i++){	$dir=$dir."/".$st[$i];	}
								$dir = strrev($dir);
								if (is_dir($dir)){
									if ($dh = opendir($dir)){
										$a = scandir($dir);
										for($j=2;$j<count($a);$j++){
											echo '<div><img data-u="image" alt="" src="'.$dir.$a[$j].'" /></div>';
										}
									closedir($dh);
									}
								}							
							}?>
            
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb057" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5000"></circle>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora073" style="width:50px;height:50px;top:0px;left:30px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="a" d="M4037.7,8357.3l5891.8,5891.8c100.6,100.6,219.7,150.9,357.3,150.9s256.7-50.3,357.3-150.9 l1318.1-1318.1c100.6-100.6,150.9-219.7,150.9-357.3c0-137.6-50.3-256.7-150.9-357.3L7745.9,8000l4216.4-4216.4 c100.6-100.6,150.9-219.7,150.9-357.3c0-137.6-50.3-256.7-150.9-357.3l-1318.1-1318.1c-100.6-100.6-219.7-150.9-357.3-150.9 s-256.7,50.3-357.3,150.9L4037.7,7642.7c-100.6,100.6-150.9,219.7-150.9,357.3C3886.8,8137.6,3937.1,8256.7,4037.7,8357.3 L4037.7,8357.3z"></path>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora073" style="width:50px;height:50px;top:0px;right:30px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="a" d="M11962.3,8357.3l-5891.8,5891.8c-100.6,100.6-219.7,150.9-357.3,150.9s-256.7-50.3-357.3-150.9 L4037.7,12931c-100.6-100.6-150.9-219.7-150.9-357.3c0-137.6,50.3-256.7,150.9-357.3L8254.1,8000L4037.7,3783.6 c-100.6-100.6-150.9-219.7-150.9-357.3c0-137.6,50.3-256.7,150.9-357.3l1318.1-1318.1c100.6-100.6,219.7-150.9,357.3-150.9 s256.7,50.3,357.3,150.9l5891.8,5891.8c100.6,100.6,150.9,219.7,150.9,357.3C12113.2,8137.6,12062.9,8256.7,11962.3,8357.3 L11962.3,8357.3z"></path>
            </svg>
        </div>
    </div>
    <script type="text/javascript">jssor_1_slider_init();</script>
				</div>
				
				<div class="row"  style="margin:5px;padding-left:5%;padding-top:2%;padding-bottom:3%;padding-right:5%;background-color:#fff;">
					<div class="row"><h4 style="font-size:20px;"><?php echo $ar['title'];?></h4></div>
					<div class="row"><p><?php echo "address";?></p></div>
					<div class="row"><span style="color:#3BAC44;font-size:20pt;">£<?php echo $ar['actual_amount'];?></span></div>
					<div class="row"><p><?php echo $ar['description'];?></p></div>
				</div>
			</div>
		</div>
		<div class="col-lg-4 col-xs-12">
			
			<div class="row"  style="background-color:#fff;margin-top:10px;margin-left:10px;padding-bottom:5%;padding:10px;border-radius:4px;" id="acpdeal">
				<h3>Deals</h3>
				<form action="" method="post" id="dealfrm">
				<ul style="list-style-type:none;padding:0;">
			<?php 
				$table_name='deal_info';
				$where_condition ='merchant_id='.$ar['merchant_id'];
				$response_array = $db->get($table_name,$where_condition); //'merchant_id=1'
				$dts=$response_array['return_message'];
				foreach($dts as $ar){					
				?>
					<li style="border-bottom:1px solid #f1f1f1;margin-top:5px;">
						<input type="radio" value="<?php echo $ar['deal_id'];?>" name="deal_id" style="margin-right:10px;" id="<?php echo $ar['deal_id'];?>" <?php if($ar['deal_id']==$psid){?>checked="checked"<?php }?>>
							<a href="index.php?page=deal_single&pro_id=<?php echo $ar['deal_id'];?>" style="text-decoration:none;color:#000;" ><?php echo $ar['title'];?></a><br>
						<i class="ico fa fa-shopping-basket mr-10" style="margin-right:10px;margin-left:5%;"></i><?php echo $ar['redemption_count'];?> Redeemed
						<div class="breakout-pricing-messages with-discount-messaging price ptb-5 text-right">
							
										<i class="ico fa fa-clock-o mr-10"></i>
										<span id="<?php echo $ar['deal_id'];?>" data-countdown="<?php echo $ar['end_date'];?>"></span>
							
                        </div>
					</li>
				<?php }?>
				</ul>
				 <input type="hidden" value="<?php echo "DATE:".time();?>" name="qrcode_string" id="qrcode">
				<input type="hidden" value="<?php echo $_SESSION['user_id'];?>" name="user_id" id="usrid">
				<input type="submit" class="btn btn-o" value="Accept" name="selection-submit" style="border:2px solid #f00;margin-top:5%;margin-bottom:5%;" id="acpbtnid">				
				<form>
			</div>
		</div>
	</div>
	<?php }	?>
	
	
	
	<div class="row" style="margin-top:5%;">
		<div class="col-lg-8" style=""> 
			<div class="row" style="background-color:#fff;margin-top:10px;margin-left:10px;padding:10px;border-radius:4px;"> <!-- margin-top:5%;padding:10px;border-radius:3px;"-->
				<?php 
					$table_name='merchant_info';
					$where_condition ='merchant_id='.$ar['merchant_id'];
					//$order_by='merchant_id';
					//echo $table_name." ".$order_by;
					$response_array = $db->get($table_name,$where_condition); //'merchant_id=1'
					//$dts=json_encode($response_array['return_message']);
					$dts=$response_array['return_message'];
					foreach($dts as $ar){					
						//echo $ar['merchant_id']."\n".$ar['business_name'];
					?>
					<h3 style="font-size:17pt;border-bottom:2px solid #f0f0f0;">About Merchant</h3>
					<img alt="" src="<?php echo $ar['image_dir'];?>" draggable="false" style="width:50%;border-radius:4px;padding:10px;float:left;">
					<h3 style="font-size:20px;text-align:center;padding-top:3px;"><?php echo $ar['business_name'];?></h3>
					<p style="font-size:15px;padding:10px;text-align:justify;"><?php echo $ar['description'];?></p>					
					<button href="" class="btn btn-o" style="margin:10px;font-size:13pt;border:2px solid #f00;">visit</button>
					
					
					<?php }
				
				?>
					
				</div>			
		</div>
		<div class="col-lg-4"  style="">
			<div class="row"  style="background-color:#fff;margin-top:10px;margin-left:10px;padding:10px;border-radius:4px;"> <!-- margin-top:5%;padding:10px;border-radius:3px;"-->
			<!-- Contact Us Widget -->
            <div class="widget contact-us-widget">
                <h3 class="widget-title">Got any questions?</h3>
                <div class="widget-body ptb-30">
                    <p class="mb-20 color-mid">If you are having any questions, please feel free to ask.</p>
                    <button href="index.php?page=contact_us" class="btn btn-block btn-o" style="border:2px solid #f00;"><i class="mr-10 font-15 fa fa-envelope-o"></i>Drop Us a Line</button>
                </div>
            </div>
            <!-- End Contact Us Widget -->
			</div>
        </div>
		
	</div>
	
	<br><br><br>
				
</div>