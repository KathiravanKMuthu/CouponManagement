<div class="container">
	

<div class="section latest-deals-area">
<header class="header-panel">
        <ul class="list-control-view list-inline">
            <li><a href="index.php?page=expdealslist"><i class="fa fa-bars"></i></a></li>
            <li><a href="index.php?page=expdeals"><i class="fa fa-th"></i></a></li>
        </ul>
</header>
<div class="row row-masnory" >
	<div class="col-sm-6 col-lg-4">
        <div class="deal-single">
			<figure class="deal-thumbnail embed-responsive embed-responsive-16by9" data-bg-img="upload/product/152957793582.png">
				<div class="label-discount">-37%</div>	
					<div class="deal-actions">   
						<span id="txtHintexpireDeal119">
							<i class="fa fa-heart" onclick="updateFavourite(2, 119, '', 'expireDeal');"></i>
						</span>
						<span>
							<i class="fa fa-share-alt" style="color;#fff;"></i>
						</span>	
						<span>
							<i class="fa fa-camera" data-toggle="modal" href="#lightbox"></i>
						</span>
						<div class="modal fade and carousel slide" id="lightbox">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-body">
										<ol class="carousel-indicators">
											<li data-target="#lightbox" data-slide-to="0" class="active"></li>
											<li data-target="#lightbox" data-slide-to="1"></li>
											<li data-target="#lightbox" data-slide-to="2"></li>
										</ol>
										<div class="carousel-inner">
											<div class="item active">
												<img src="http://placehold.it/900x500/777/" alt="First slide">
											</div>
											<div class="item">
												<img src="http://placehold.it/900x500/666/" alt="Second slide">
											</div>
											<div class="item">
												<img src="http://placehold.it/900x500/555/" alt="Third slide">
												<div class="carousel-caption"><p>even with captions...</p></div>
											</div>
										</div><!-- /.carousel-inner -->
										<a class="left carousel-control" href="#lightbox" role="button" data-slide="prev">
    										<span class="glyphicon glyphicon-chevron-left"></span>
										</a>
										<a class="right carousel-control" href="#lightbox" role="button" data-slide="next">
											<span class="glyphicon glyphicon-chevron-right"></span>
										</a>
									</div><!-- /.modal-body -->
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->
					</div>							
					<div class="time-left">
                        <span>
							<i class="ico fa fa-clock-o mr-10"></i>
							<span class="t-uppercase disabled" data-countdown="2018/07/31 23:59:59">This offer have expired!</span>
						</span>
                    </div>
                    <div class="deal-store-logo">
                        <img src="images/ven/1529577868749.png" alt="">
                    </div>
                </figure>
					<div class="" style="background-color:white;padding-top:5px;padding-left:20px;padding-right:15px;">
						<div class="pr-md-10" style="padding-right: 10px;">
                            <h3 class="deal-title" style="font-size: 20px;">
                       			<a style="text-decoration:none;" data-tooltip data-toggle="tooltip" data-placement="bottom" title="" 
									data-original-title="Plumbing, Heating, Bathroom, Electric and General Building Materials" href="index.php?page=deal_single&amp;pro_id=119"> Plumbing, Heating, Bathroom</a>                                       
                   			</h3>
                            <a href="https://www.dealdio.com/index.php?page=deal_single&amp;pro_id=119" style="text-decoration:none;">
								<h6 style="color:#26CC71;font-size: 14px;">WISE-GUYS PLUMBING AND PLASTICS</h6>
								<ul class="deal-meta list-inline mb-10 color-mid" style="margin-bottom:10px;color: #717f86;">
									<li><i class="ico fa fa-map-marker mr-10"></i>12 Watford Road, Wembley, HA0 3EP</li>
								</ul>
								<p class="text-muted mb-20">We supply Plumbing, Heating &amp; Electrical...</p>
                            </a>
                        </div>
                        <div class="deal-price pos-r mb-15" style="position:relative;margin-bottom: 15px;">
							<ul class="deal-meta list-inline mb-10 color-mid">
                                <li><i class="ico fa fa-shopping-basket mr-10"></i>1 Redeemed</li>
								<li>
									<h3 class="price" style="padding-top:5px;padding-bottom:5px;text-align:right;color: #3BAC44;margin-bottom: 0">
									<span class="price-sale" style="color: #d84523; font-size: 85%;   text-decoration: line-through;
									margin-right: 1em;">�399.00</span>�250.00                                                                                                        </h3>
                                </li>
                            </ul>
                        </div>
                    </div>
				</div>
            </div>
		</div>
	</div>