<?php
/* Application configuration goes here */

define('CLIENT_NAME', 'DealDio');
define('CLIENT_DISP_NAME', 'Deal Dio')

?>

